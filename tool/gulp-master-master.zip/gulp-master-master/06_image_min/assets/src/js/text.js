var app = (function(document){
    document.getElementById("logo").innerHTML = "Gulp";
    document.getElementById("logoDesc").innerHTML = "Automate and enhance your workflow";
    document.getElementById("video").innerHTML = "gulp-imagemin";
})(document);